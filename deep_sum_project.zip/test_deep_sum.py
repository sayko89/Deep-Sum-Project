import unittest
from deep_sum import deep_sum

class TestDeepSum(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(deep_sum([1, 2, 3]), 6)

    def test_nested(self):
        data = {"a": 5, "b": [3, {"c": 2.5, "d": [1, {"e": 4}]}]}
        self.assertEqual(deep_sum(data), 15.5)

    def test_with_non_numbers(self):
        data = [1, "abc", None, True, {"x": False, "y": [7, "z"]}]
        self.assertEqual(deep_sum(data), 8)