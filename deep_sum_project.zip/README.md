# DeepSum – İç İçe Sayısal Veri Toplayıcı

Bu Python projesi, iç içe geçmiş liste, sözlük, set ve tuple veri yapılarını tarayarak içindeki tüm sayısal değerleri toplar.

## Kullanım
```bash
python main.py
```

## Test Çalıştırma
```bash
python -m unittest test_deep_sum.py
```