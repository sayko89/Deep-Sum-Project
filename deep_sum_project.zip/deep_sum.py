def deep_sum(data):
    toplam = 0

    if isinstance(data, (int, float)) and not isinstance(data, bool):
        return data

    elif isinstance(data, dict):
        for value in data.values():
            toplam += deep_sum(value)

    elif isinstance(data, (list, tuple, set)):
        for item in data:
            toplam += deep_sum(item)

    return toplam