def header():
    return "\n" + "="*50 + "\n" + "📊 DEEP SUM ANALİZ UYGULAMASI".center(50) + "\n" + "="*50