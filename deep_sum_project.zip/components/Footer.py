def footer():
    return "\n" + "="*50 + "\n" + "© 2025 UNIDEV Software".center(50) + "\n" + "="*50