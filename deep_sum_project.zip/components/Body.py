def body():
    return "\nVeri analizi başlatılıyor...\n"