import json
from deep_sum import deep_sum
from components.Header import header
from components.Body import body
from components.Footer import footer

if __name__ == "__main__":
    print(header())
    print(body())

    with open("examples/sample1.json", "r") as file:
        data = json.load(file)

    toplam = deep_sum(data)
    print("Sayısal değerlerin toplamı:", toplam)

    print(footer())